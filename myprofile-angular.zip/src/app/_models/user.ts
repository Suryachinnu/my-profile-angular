export interface User{
    name: string;
    company: string;
    experience: string;
    designation: string;
    qualification: string;
}
