export interface Interest{
    id: number;
    name: string;
    description: string;
}
