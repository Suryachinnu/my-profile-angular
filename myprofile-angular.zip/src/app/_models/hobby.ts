export interface Hobby{
    id: number;
    name: string;
}
